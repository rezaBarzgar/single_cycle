int main(){
	int[] a ={1,2,3,4,5,6,7,8,9};
	int max=a[0],min=a[0];
	int i;
	for(i=1;i<9;i++){
		if(a[i]>max) max= a[i];
		if(a[i]<min) min = a[i];
	}
}
